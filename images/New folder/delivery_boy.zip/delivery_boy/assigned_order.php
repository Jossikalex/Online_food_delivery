<?php
// Hide all errors to show blank space on failure
error_reporting(0);
ini_set('display_errors', 0);

session_start();

// Go up one directory to find connection.php
require_once "../connection.php";

/* 🔐 SECURITY CHECK */
if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'delivery'
) {
    header("Location: ../login.php");
    exit();
}

// Use $connect (matches connection.php)
if (!$connect) {
    exit(); 
}

$deliveryId = (int) $_SESSION['user_id'];

/* 📦 FETCH ASSIGNED ORDERS */
$sql = "
    SELECT 
        o.order_id,
        o.status,
        c.Fname,
        c.Lname,
        o.delivery_address
    FROM orders o
    JOIN Customer c ON o.cust_id = c.cust_id
    WHERE o.del_id = ?
      AND o.status = 'ready'
";

$stmt = mysqli_prepare($connect, $sql);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $deliveryId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assigned Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="delivery_person.css">
</head>
<body>

<header class="header">
    <span class="brand">Ella Kitchen Delivery</span>
</header>

<main class="content">
    <h2>Assigned Orders</h2>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Address</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$result || mysqli_num_rows($result) === 0): ?>
            <tr>
                <td colspan="5">No assigned orders</td>
            </tr>
            <?php else: ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= (int)$row['order_id'] ?></td>
                    <td><?= htmlspecialchars($row['Fname'] . ' ' . $row['Lname']) ?></td>
                    <td><?= htmlspecialchars($row['delivery_address']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td>
                        <a href="accept_order.php?id=<?= (int)$row['order_id'] ?>">Accept</a> |
                        <a href="reject_order.php?id=<?= (int)$row['order_id'] ?>"
                           onclick="return confirm('Reject this order?')">Reject</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <br>
    <a href="../logout.php">Logout</a>
</main>

</body>
</html>