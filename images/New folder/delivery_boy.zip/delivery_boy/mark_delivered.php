<?php
session_start();
require_once "connection.php";

/* ===============================
   SECURITY: LOGIN + ROLE CHECK
   =============================== */
if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'delivery'
) {
    header("Location: login.php");
    exit();
}

/* ===============================
   VALIDATE INPUT
   =============================== */
if (!isset($_GET['id'])) {
    header("Location: current_delivery.php");
    exit();
}

$orderId    = (int) $_GET['id'];
$deliveryId = (int) $_SESSION['user_id'];

/* ===============================
   1️⃣ MARK ORDER AS DELIVERED
   =============================== */
$sqlOrder = "
    UPDATE orders
    SET status = 'delivered',
        actual_delivery = NOW()
    WHERE order_id = ?
      AND del_id   = ?
";

$stmt1 = mysqli_prepare($conn, $sqlOrder);
mysqli_stmt_bind_param($stmt1, "ii", $orderId, $deliveryId);
mysqli_stmt_execute($stmt1);

/* ===============================
   2️⃣ SET DELIVERY PERSON AVAILABLE
   =============================== */
$sqlDelivery = "
    UPDATE Delivery_person
    SET status = 'available'
    WHERE del_id = ?
";

$stmt2 = mysqli_prepare($conn, $sqlDelivery);
mysqli_stmt_bind_param($stmt2, "i", $deliveryId);
mysqli_stmt_execute($stmt2);

/* ===============================
   REDIRECT
   =============================== */
header("Location: current_delivery.php?delivered=1");
exit();
