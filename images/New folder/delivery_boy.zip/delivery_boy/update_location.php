<?php
session_start();
require_once 'connection.php';

header('Content-Type: application/json');

/* ===============================
   SECURITY: LOGIN CHECK
   =============================== */
if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'customer'
) {
    echo json_encode(['ok' => false, 'msg' => 'Unauthorized']);
    exit;
}

/* ===============================
   READ JSON INPUT
   =============================== */
$data = json_decode(file_get_contents('php://input'), true);

$orderId = (int) ($data['order_id'] ?? 0);
$lat     = isset($data['lat']) ? (float) $data['lat'] : null;
$lng     = isset($data['lng']) ? (float) $data['lng'] : null;

if (!$orderId || $lat === null || $lng === null) {
    echo json_encode(['ok' => false, 'msg' => 'Invalid data']);
    exit;
}

/* ===============================
   ENSURE CUSTOMER OWNS ORDER
   =============================== */
$checkSql = "
    SELECT order_id
    FROM Orders
    WHERE order_id = ?
      AND cust_id  = ?
";

$checkStmt = mysqli_prepare($conn, $checkSql);
mysqli_stmt_bind_param($checkStmt, "ii", $orderId, $_SESSION['user_id']);
mysqli_stmt_execute($checkStmt);
$checkRes = mysqli_stmt_get_result($checkStmt);

if (mysqli_num_rows($checkRes) === 0) {
    echo json_encode(['ok' => false, 'msg' => 'Order not found']);
    exit;
}

/* ===============================
   UPDATE LOCATION
   =============================== */
$updateSql = "
    UPDATE Orders
    SET latitude = ?, longitude = ?
    WHERE order_id = ?
";

$updateStmt = mysqli_prepare($conn, $updateSql);
mysqli_stmt_bind_param($updateStmt, "ddi", $lat, $lng, $orderId);
mysqli_stmt_execute($updateStmt);

echo json_encode(['ok' => true]);
exit;
?>
