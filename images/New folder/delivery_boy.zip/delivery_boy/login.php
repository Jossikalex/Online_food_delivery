<?php
session_start();
require_once "connection.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = "All fields are required.";
    } else {

        $sql = "
            SELECT user_id, username, password_hash, role, is_active
            FROM Users
            WHERE username = ?
            LIMIT 1
        ";

        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($user = mysqli_fetch_assoc($result)) {

            if ((int)$user['is_active'] !== 1) {
                $error = "Account is inactive. Contact administrator.";
            }
            elseif (password_verify($password, $user['password_hash'])) {

                session_regenerate_id(true);

                $_SESSION['user_id']  = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role']     = $user['role'];

                switch ($user['role']) {

                    case 'admin':
                        header("Location: admin/dashboard.php");
                        break;

                    case 'manager':
                        header("Location: manager/dashboard.php");
                        break;

                    case 'waiter':
                        header("Location: waiter/dashboard.php");
                        break;

                    case 'delivery':
                        header("Location: delivery_boy/assigned_order.php");
                        break;

                    case 'customer':
                        header("Location: customer/home.php");
                        break;

                    default:
                        header("Location: login.php");
                }
                exit;

            } else {
                $error = "Invalid username or password.";
            }

        } else {
            $error = "Invalid username or password.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(120deg, #ff6b6b, #feca57);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
.login-box {
    background: #fff;
    width: 350px;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}
.login-box h2 {
    text-align: center;
    margin-bottom: 20px;
}
.login-box input,
.login-box button {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
}
.login-box button {
    background: #ff6b6b;
    border: none;
    color: #fff;
    cursor: pointer;
}
.error {
    background: #ffe6e6;
    color: #c0392b;
    padding: 10px;
    margin-bottom: 15px;
    text-align: center;
}
</style>
</head>

<body>

<div class="login-box">
    <h2>Login</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
