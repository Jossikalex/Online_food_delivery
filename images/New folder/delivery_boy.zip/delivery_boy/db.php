<?php
$conn = new mysqli("localhost", "root", "", "ella_delivery");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

mysqli_set_charset($conn, "utf8mb4");
date_default_timezone_set("Africa/Addis_Ababa");
?>
